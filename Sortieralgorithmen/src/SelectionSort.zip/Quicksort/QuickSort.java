package Quicksort;

public class QuickSort {
	private int [] liste;
	
	public QuickSort(int length) {
		liste = new int[length];
		fill(0, length);
	}
	
	public void fill(int min, int max) {
		min--;
		for (int i = 0; i < liste.length; i++) {
			liste[i] = (int)(Math.random()*(max-min+1)+min);
		}
	}
	
	public void print() {
		for (int i = 0; i < liste.length; i++) {
			System.out.print(liste[i]+"; ");
		}
		System.out.println();
	}
	
	public void sort() {
		sort(0, this.liste.length-1);
	}
	
	public void sort(int low, int high) {
		if (low < high) {
			int pivot = part(low, high);
			sort(low, pivot-1);
			sort(pivot+1, high);
		}
	}
	
	public int part(int low, int high) {
		int pivot = liste[high];
		int low_speicher = low;
		int high_speicher = high;
		while(low < high) {
			while(high > low_speicher && liste[high] >= pivot) {
				high--;
			}
			while(low < high_speicher && liste[low] < pivot) {
				low++;
			}
			if (low < high) {
				int help = liste[low];
				liste[low] = liste[high];
				liste[high] = help;
			}
		}
		if (liste[low] > pivot) {
			int help = liste[high_speicher];
			liste[high_speicher] = liste[low];
			liste[low] = help;
		}
		return low;
	}
}
