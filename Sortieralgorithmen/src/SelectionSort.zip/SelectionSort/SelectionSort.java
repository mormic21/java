package SelectionSort;
public class SelectionSort {

	private int [] liste;
	
	public SelectionSort(int length) {
		liste = new int[length];
		fill(0, length);
	}
	
	public void fill(int min, int max) {
		min--;
		for (int i = 0; i < liste.length; i++) {
			liste[i] = (int)(Math.random()*(max-min+1)+min);
		}
	}
	
	public void print() {
		for (int i = 0; i < liste.length; i++) {
			System.out.print(liste[i]+"; ");
		}
		System.out.println();
	}
	
	
	public void sort() {
		for (int i = 0; i < liste.length; i++) {
			int minIndex = i;
			for (int j = minIndex+1; j < liste.length; j++) {
				if (liste[minIndex] > liste[j]) {
					minIndex = j;
				}
			}
			int memory = liste[i];
			liste[i] = liste[minIndex];
			liste[minIndex] = memory;
		}
	}
}
